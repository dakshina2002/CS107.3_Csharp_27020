﻿namespace Lab_Sheet_05___Question_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SayHello sayHelloObject = new SayHello();

            sayHelloObject.sayHello();
        }
    }
}